"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.handler = void 0;
const client_s3_1 = require("@aws-sdk/client-s3");
const s3Client = new client_s3_1.S3Client({ region: process.env.AWS_REGION });
const handler = async (event) => {
    var _a;
    const bucketName = process.env.AWS_S3_BUCKET;
    const expirationDays = parseInt(process.env.EXPIRATION_DAYS || "7");
    try {
        const listObjectsResponse = await s3Client.send(new client_s3_1.ListObjectsV2Command({
            Bucket: bucketName,
            Prefix: "", // 可設定前綴
        }));
        if (listObjectsResponse.Contents) {
            const objectsToDelete = [];
            for (const obj of listObjectsResponse.Contents) {
                const headObjectResponse = await s3Client.send(new client_s3_1.HeadObjectCommand({
                    Bucket: bucketName,
                    Key: obj.Key,
                }));
                const isTemporary = ((_a = headObjectResponse.Metadata) === null || _a === void 0 ? void 0 : _a.temporary) === "true";
                const uploadTime = new Date(headObjectResponse.LastModified);
                if (isTemporary &&
                    (new Date().getTime() - uploadTime.getTime()) /
                        (1000 * 60 * 60 * 24) >
                        expirationDays) {
                    objectsToDelete.push({ Key: obj.Key });
                }
            }
            if (objectsToDelete.length > 0) {
                await s3Client.send(new client_s3_1.DeleteObjectsCommand({
                    Bucket: bucketName,
                    Delete: { Objects: objectsToDelete },
                }));
                console.log(`Deleted ${objectsToDelete.length} objects`);
            }
        }
        return {
            statusCode: 200,
            body: JSON.stringify("Cleanup complete"),
        };
    }
    catch (error) {
        console.error("Error cleaning up unused files:", error);
        return {
            statusCode: 500,
            body: JSON.stringify("Error occurred"),
        };
    }
};
exports.handler = handler;
