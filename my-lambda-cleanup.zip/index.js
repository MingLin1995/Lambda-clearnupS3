"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.handler = void 0;
const client_s3_1 = require("@aws-sdk/client-s3");
const node_http_handler_1 = require("@aws-sdk/node-http-handler");
const https_1 = require("https");
// 初始化 S3
const s3Client = new client_s3_1.S3Client({
    region: process.env.AWS_REGION,
    requestHandler: new node_http_handler_1.NodeHttpHandler({
        httpsAgent: new https_1.Agent({ keepAlive: false }),
    }),
});
const oneDayInMs = 24 * 60 * 60 * 1000; // 一天
const handler = async (event, context) => {
    context.callbackWaitsForEmptyEventLoop = false;
    console.log("Lambda handler start");
    try {
        const totalDeletedObjects = await processAllObjects();
        console.log("Lambda handler success");
        return {
            statusCode: 200,
            body: JSON.stringify(`清理完成，總共刪除 ${totalDeletedObjects} 個檔案`),
        };
    }
    catch (error) {
        console.error("清理過期文件時出錯:", error);
        return {
            statusCode: 500,
            body: JSON.stringify("發生錯誤"),
        };
    }
};
exports.handler = handler;
/**
 * 處理 S3 存儲桶中的所有物件
 * @returns 刪除的物件總數
 */
async function processAllObjects() {
    console.log("processAllObjects start");
    const bucketName = process.env.AWS_S3_BUCKET;
    let totalDeletedObjects = 0;
    let continuationToken;
    try {
        // 分頁處理
        do {
            const listObjectsResponse = await s3Client.send(new client_s3_1.ListObjectsV2Command({
                Bucket: bucketName,
                ContinuationToken: continuationToken,
            }));
            if (listObjectsResponse.Contents) {
                const objectsToDelete = await processObjectsInBatches(bucketName, listObjectsResponse.Contents, 20);
                const filteredObjectsToDelete = objectsToDelete.filter((obj) => obj !== null);
                if (filteredObjectsToDelete.length > 0) {
                    await deleteObjects(bucketName, filteredObjectsToDelete);
                    totalDeletedObjects += filteredObjectsToDelete.length;
                    console.log(`已刪除 ${filteredObjectsToDelete.length} 個檔案`);
                }
            }
            continuationToken = listObjectsResponse.NextContinuationToken;
        } while (continuationToken);
        console.log("processAllObjects end");
        return totalDeletedObjects;
    }
    catch (err) {
        console.error("processAllObjects error:", err);
        throw err;
    }
}
/**
 * 批次分流處理物件陣列，限制併發數 (Batch Chunking)，避免 N+1 請求過載與 S3 Rate Limit 限制
 */
async function processObjectsInBatches(bucketName, contents, batchSize = 20) {
    const results = [];
    for (let i = 0; i < contents.length; i += batchSize) {
        const batch = contents.slice(i, i + batchSize);
        const batchResults = await Promise.all(batch.map((obj) => processObject(bucketName, obj)));
        results.push(...batchResults);
    }
    return results;
}
/**
 * 處理單個物件，決定是否需要刪除
 * @param bucketName S3 存儲桶名稱
 * @param obj S3 物件
 * @returns 如果物件需要刪除，返回包含 Key 的物件；否則返回 null
 */
async function processObject(bucketName, obj) {
    var _a, _b, _c;
    if (!obj || !obj.Key)
        return null;
    const now = new Date();
    const uploadTime = obj.LastModified ? new Date(obj.LastModified) : new Date();
    const fileAgeMs = now.getTime() - uploadTime.getTime();
    // 1. 上傳未滿 24 小時的檔案，絕不可能為已過期的暫存檔，直接跳過 (省去 HEAD 請求)
    if (fileAgeMs < oneDayInMs) {
        return null;
    }
    // 2. 超過 7 天且非 PickupRequest/ 的檔案，代表早已確定寫入 DB 並轉為永久檔案，直接跳過 (省去 HEAD 請求)
    const isPickupRequest = obj.Key.startsWith("PickupRequest/");
    if (!isPickupRequest && fileAgeMs > 7 * oneDayInMs) {
        return null;
    }
    // 3. 僅對需進一步確認元數據的檔案發送 HeadObjectCommand
    try {
        const headObjectResponse = await s3Client.send(new client_s3_1.HeadObjectCommand({
            Bucket: bucketName,
            Key: obj.Key,
        }));
        const isTemporary = ((_a = headObjectResponse.Metadata) === null || _a === void 0 ? void 0 : _a.temporary) === "true";
        if (isTemporary && fileAgeMs > oneDayInMs) {
            console.log("processObject: will delete temporary file", obj.Key);
            return { Key: obj.Key };
        }
        else if (isPickupRequest && !isTemporary) {
            const expirationDate = ((_b = headObjectResponse.Metadata) === null || _b === void 0 ? void 0 : _b.expirationDate) ||
                ((_c = headObjectResponse.Metadata) === null || _c === void 0 ? void 0 : _c.expirationdate);
            if (expirationDate && now > new Date(expirationDate)) {
                console.log("processObject: will delete expired PickupRequest", obj.Key);
                return { Key: obj.Key };
            }
        }
        return null;
    }
    catch (err) {
        console.error("processObject error:", obj.Key, err);
        return null;
    }
}
/**
 * 從 S3 存儲桶中刪除指定的物件
 * @param bucketName S3 存儲桶名稱
 * @param objects 要刪除的物件
 */
async function deleteObjects(bucketName, objects) {
    console.log("deleteObjects start", objects.map(o => o.Key));
    try {
        await s3Client.send(new client_s3_1.DeleteObjectsCommand({
            Bucket: bucketName,
            Delete: { Objects: objects },
        }));
        console.log("deleteObjects success", objects.map(o => o.Key));
    }
    catch (err) {
        console.error("deleteObjects error:", err);
        throw err;
    }
}
