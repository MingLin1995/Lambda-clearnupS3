"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.handler = void 0;
const client_s3_1 = require("@aws-sdk/client-s3");
// 初始化 S3
const s3Client = new client_s3_1.S3Client({ region: process.env.AWS_REGION });
const oneDayInMs = 24 * 60 * 60 * 1000; // 一天
const handler = async (event) => {
    try {
        const totalDeletedObjects = await processAllFolders();
        return {
            statusCode: 200,
            body: JSON.stringify(`清理完成，總共刪除 ${totalDeletedObjects} 個檔案`),
        };
    }
    catch (error) {
        console.error("清理過期文件時出錯:", error);
        return {
            statusCode: 500,
            body: JSON.stringify("發生錯誤"),
        };
    }
};
exports.handler = handler;
/**
 * 處理指定的資料夾
 * @returns 刪除的檔案總數
 */
async function processAllFolders() {
    const bucketName = process.env.AWS_S3_BUCKET;
    // 處理 Common 和 PickupRequest 兩個資料夾
    const folders = ["Common", "PickupRequest"];
    let totalDeletedObjects = 0;
    for (const folder of folders) {
        totalDeletedObjects += await processFolderContents(bucketName, folder);
    }
    return totalDeletedObjects;
}
/**
 * 處理資料夾中所有檔案
 * @returns 刪除的檔案數量
 */
async function processFolderContents(bucketName, folder) {
    const listObjectsResponse = await s3Client.send(new client_s3_1.ListObjectsV2Command({
        Bucket: bucketName,
        Prefix: `${folder}/`, // 取得的資料夾前綴
    }));
    if (!listObjectsResponse.Contents) {
        return 0;
    }
    const objectsToDelete = await Promise.all(listObjectsResponse.Contents.map((obj) => processObject(bucketName, folder, obj)));
    const filteredObjectsToDelete = objectsToDelete.filter((obj) => obj !== null);
    if (filteredObjectsToDelete.length > 0) {
        await deleteObjects(bucketName, filteredObjectsToDelete);
        console.log(`已從 ${folder} 資料夾刪除 ${filteredObjectsToDelete.length} 個資料`);
    }
    return filteredObjectsToDelete.length;
}
/**
 * 檢查是否應該要刪除
 * @returns 如果對象需要刪除，回傳 Key；否則回傳 null
 */
async function processObject(bucketName, folder, obj) {
    var _a, _b;
    // 取得S3所有資料
    const headObjectResponse = await s3Client.send(new client_s3_1.HeadObjectCommand({
        Bucket: bucketName,
        Key: obj.Key,
    }));
    const isTemporary = ((_a = headObjectResponse.Metadata) === null || _a === void 0 ? void 0 : _a.temporary) === "true";
    const uploadTime = new Date(headObjectResponse.LastModified);
    const now = new Date();
    if (isTemporary && now.getTime() - uploadTime.getTime() > oneDayInMs) {
        // 暫時性文件，檢查是否超過一天
        return { Key: obj.Key };
    }
    else if (folder === "PickupRequest" && !isTemporary) {
        // PickupRequest 中的非暫時性文件，檢查 expirationDate
        const expirationDate = (_b = headObjectResponse.Metadata) === null || _b === void 0 ? void 0 : _b.expirationDate;
        if (expirationDate && now > new Date(expirationDate)) {
            return { Key: obj.Key };
        }
    }
    return null;
}
async function deleteObjects(bucketName, objects) {
    await s3Client.send(new client_s3_1.DeleteObjectsCommand({
        Bucket: bucketName,
        Delete: { Objects: objects },
    }));
}
